#ifndef _KEY_H_
#define _KEY_H_




void Key_Init(void);


#endif
