#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define LED PBout(5)// PB5
#define LED1 PEout(5)// PE5	

#define LED_OFF1	1
#define LED_ON1		0

void LED_Init(void);//��ʼ��
			    
#endif
