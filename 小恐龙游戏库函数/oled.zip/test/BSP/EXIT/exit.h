#ifndef __EXIT_H
#define __EXIT_H
#include "stm32f10x.h"
void EXTI_INIT(void);

#endif

