#include "stm32f10x.h"
#include "key.h"
#include "delay.h"

//������ʼ������
void KEY_Init(void) //IO��ʼ��
{ 
 	GPIO_InitTypeDef GPIO_InitStructure;
 
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);//ʹ��PORTA,PORTEʱ��

	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4|GPIO_Pin_3;//KEY0-KEY1
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //���ó���������
 	GPIO_Init(GPIOE, &GPIO_InitStructure);//��ʼ��GPIOE4,3
}


u8 Key_Scan(void)
{
	if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4)==0)
	{
		delay_ms(10);
		if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4)==0)
		{
				return 1;
		}
	}
	/////////////////////////
	if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3)==0)
	{
		delay_ms(10);
		if(GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3)==0)
		{
			return 2;
		}
	}
	return 0;
}

