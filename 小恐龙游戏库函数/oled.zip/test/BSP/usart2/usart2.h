#ifndef  __USART2_H_
#define  __USART2_H_
#include "stdio.h"	
#include "stm32f10x.h" 

void uart2_init(u32 bound);
#endif








